from tkinter import *
from tkinter import Menu
from tkinter.filedialog import askopenfilename, asksaveasfilename
import os
global text
global master
def newFile():
    global file
    master.title("Untitled ")
    file =None
    text.delete(1.0,END)
def openFile():
    global file
    file = askopenfilename(defaultextension=".txt",filetypes=[("All Files", "*.*"),("Text Documents", "*.txt")])
    if file == "":
        file = None
    else:
        master.title(os.path.basename(file) + " - Notepad")
        text.delete(1.0, END)
        f = open(file, "r")
        text.insert(1.0, f.read())
        f.close()

def algo():
    # import the time module
    global file, p
    if file == None:
        file = asksaveasfilename(initialfile='input.txt', defaultextension=".txt",
                                 filetypes=[("All Files", "*.*"),
                                            ("Text Documents", "*.txt")])
        if file == "":
            file = None

        else:
            # Save as a new file
            f = open(file, "w")
            f.write(text.get(1.0, END))
            f.close()

            master.title(os.path.basename(file) + " - Notepad")
            print("File Saved")
    else:
        # Save the file
        f = open(file, "r")
        f.write(text.get(1.0, END))
        f.close()
    import tkinter.messagebox
    tkinter.messagebox.showinfo('Note', ' It will take some time')
    from Algo import write
    from Algo import word
    from Algo import letterwrite
    from Algo import BG
    from Algo import BG1
    from PIL import Image
    tru = True
    if tru:
        try:
            with open('input.txt', 'r+') as file:
                data = file.read().replace('\n', '\n')
            l = len(data)
            nn = len(data) // 600
            chunks, chunk_size = len(data), len(data) // (nn + 1)
            p= [data[i:i + chunk_size] for i in range(0, chunks, chunk_size)]

            for i in range(0, len(p)):
                word(p[i])
                write('\n')
                BG.save('%doutt.png' % i)
                BG1 = Image.open("bg.png")
                BG = BG1
                gap = 0
                _ = 0

        except ValueError as E:
            print("{}\nTry again".format(E))


    tkinter.messagebox.showinfo('Process Done ', ' Now you can Check the File')
'''
    from PIL import Image
    from fpdf import FPDF
    imagelist = []
    for i in range(0, len(p)):
        imagelist.append('%doutt.png' % i)
    cover = Image.open(imagelist[0])
    width, height = cover.size

    pdf = FPDF(unit="pt", format=[width, height])
    for i in range(0, len(imagelist)):
        pdf.add_page()
        pdf.image(imagelist[i], 0, 0)
    pdf.output("output.pdf", "F")'''

        # input time in second

def saveFile():
    global file
    if file == None:
        file = asksaveasfilename(initialfile='Untitled.txt', defaultextension=".txt",
                                 filetypes=[("All Files", "*.*"),
                                            ("Text Documents", "*.txt")])
        if file == "":
            file = None

        else:
            # Save as a new file
            f = open(file, "w")
            f.write(text.get(1.0, END))
            f.close()

            master.title(os.path.basename(file) + " - Notepad")
            print("File Saved")
    else:
        # Save the file
        f = open(file, "w")
        f.write(text.get(1.0, END))
        f.close()

def cut():
    text.event_generate(("<<Cut>>"))
def copy():
    text.event_generate(("<<Copy>>"))
def paste():
    text.event_generate(("<<Paste>>"))
def quitApp():
    master.destroy()

def change_th():
# do know what  to so if i change "text " to globle othrt function cant use it and if i dont thhen i cant change colour

#methord 3
    if True:
        global master
        master = Tk()
        master.title("Notepad")
        master.geometry("440x720")
        # type area

        bgcol = 'black'

        fgcol = 'white'
        global text
        text = Text(master, font="lucida 13", bg=bgcol, fg=fgcol)
        global file
        file = None
        text.pack(expand=True, fill=BOTH)
        # menubar

        menu_bar = Menu(master)
        file_menu = Menu(menu_bar, tearoff=0)
        # file
        # new file
        file_menu.add_command(label="New", command=newFile)
        # open file
        file_menu.add_command(label="Open", command=openFile)

        file_menu.add_command(label="Save", command=saveFile, bgcol='black', fgcol='white')
        file_menu.add_command(label="change theme", command=change_th)
        file_menu.add_command(label="convet to handwriting", command=algo)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=quitApp)
        menu_bar.add_cascade(label="File", menu=file_menu)
        # edit menu
        edit_menu = Menu(menu_bar, tearoff=0)
        edit_menu.add_command(label="cut", command=cut)
        edit_menu.add_command(label="copy", command=copy)
        edit_menu.add_command(label="paste", command=paste)
        menu_bar.add_cascade(label="Edit", menu=edit_menu)
        master.config(menu=menu_bar)
        Scroll = Scrollbar(text)
        Scroll.pack(side=RIGHT, fill=Y)
        Scroll.config(command=text.yview)
        text.config(yscrollcommand=Scroll.set)
        master.mainloop()

def runpad ():
    if True:
        global master
        master = Tk()
        master.title("Notepad")
        master.geometry("440x720")
        # type area

        bgcol = 'white'

        fgcol = 'black'
        global text
        text = Text(master, font="lucida 13", bg=bgcol, fg=fgcol)
        global file
        file = None
        text.pack(expand =True ,fill =BOTH)
        # menubar

        menu_bar = Menu(master)
        file_menu = Menu(menu_bar, tearoff=0)
        # file
        # new file
        file_menu.add_command(label="New", command=newFile)
        # open file
        file_menu.add_command(label="Open", command=openFile)

        file_menu.add_command(label="Save", command=saveFile)
        file_menu.add_command(label="change theme", command=change_th)
        file_menu.add_command(label="Convert to Handwriting", command=algo)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=quitApp)
        menu_bar.add_cascade(label="File", menu=file_menu)
        # edit menu
        edit_menu = Menu(menu_bar, tearoff=0)
        edit_menu.add_command(label="cut", command=cut)
        edit_menu.add_command(label="copy", command=copy)
        edit_menu.add_command(label="paste", command=paste)
        menu_bar.add_cascade(label="Edit", menu=edit_menu)
        master.config(menu=menu_bar)
        Scroll = Scrollbar(text)
        Scroll.pack(side=RIGHT, fill=Y)
        Scroll.config(command=text.yview)
        text.config(yscrollcommand=Scroll.set)
        master.mainloop()
runpad()