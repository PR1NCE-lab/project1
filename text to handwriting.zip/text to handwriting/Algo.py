from PIL import Image
BG = Image.open("bg.png")
sizeOfSheet = BG.width
gap, _= 25,33
allowedChars = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM,.-?!() 1234567890\t\n'


def write(char):
    global gap, _
    if char == '\n':	
        gap = 25
        _ += 150

    elif char == '\t':	
        _ += 150
        gap = 0

    else:
        char.lower()
        cases = Image.open("%s.png" % char)
        BG.paste(cases, (gap, _))
        size = cases.width
        gap += size
        del cases


def letterwrite(word):
    global gap, _
    if gap > sizeOfSheet - 50*(len(word)):
        gap = 25
        _ += 20
    for letter in word:        
        if letter in allowedChars:
            if letter.islower():
                pass
            elif letter.isupper():
                letter = letter.lower()
                letter += 'upper'            
            elif letter == '.':
                letter = "fullstop"
            elif letter == '!':
                letter = 'exclamation'
            elif letter == '?':
                letter = 'question'
            elif letter == ',':
                letter = 'comma'
            elif letter == '(':
                letter = 'braketop'
            elif letter == ')':
                letter = 'braketcl'
            elif letter == '-':
                letter = 'hiphen'
            elif letter == '\n':
                letter = '\n'

            write(letter)


def word(Input):
    wordlist = Input.split(' ')
    for i in wordlist:
        letterwrite(i)
        write('space')

tru = True
if tru:
    try:
        with open('input.txt', 'r') as file:
            data = file.read().replace('\n', '\n')
        l = len(data)
        nn = len(data)//600
        chunks, chunk_size = len(data), len(data)//(nn+1)
        p = [data[i:i+chunk_size] for i in range(0, chunks, chunk_size) ]
        
        for i in range(0,len(p)):
            word(p[i])
            write('\n')
            BG.save('%doutt.png'%i)
            BG1= Image.open("bg.png")
            BG=BG1
            gap = 0
            _ =0
    except ValueError as E:
        print("{}\nTry again".format(E))
    tru = False
from PIL import Image
from fpdf import FPDF
imagelist=[]
for i in range(0,2):
    imagelist.append('%doutt.png'%i)
cover = Image.open(imagelist[0])
width, height = cover.size

pdf = FPDF(unit = "pt", format = [width, height])
for i in range(0,len(imagelist)):
    pdf.add_page()
    pdf.image(imagelist[i], 0, 0)
pdf.output("output.pdf", "F")




